"""Apply the selected channel only after validating every changed source file."""
from pathlib import Path
import argparse
import hashlib
import json
import shutil

parser=argparse.ArgumentParser()
parser.add_argument('--channel',choices=['stable','beta'],required=True)
parser.add_argument('--repo',type=Path,required=True)
parser.add_argument('--apply',action='store_true')
args=parser.parse_args()
bundle=Path(__file__).resolve().parent/args.channel
repo=args.repo.resolve()
manifest=json.loads((bundle/'manifest.json').read_text())
changes=[]
for item in manifest['files']:
    target=(repo/item['path']).resolve()
    if not target.is_relative_to(repo):raise SystemExit('Invalid destination path')
    source=bundle/'changes'/item['path']
    raw=source.read_bytes()
    if hashlib.sha256(raw).hexdigest()!=item['sha256']:raise SystemExit('Bundle checksum mismatch: '+item['path'])
    current=target.read_bytes() if target.exists() else None
    if current is not None and hashlib.sha256(current).hexdigest()==item['sha256']:continue
    blob=hashlib.sha1(b'blob '+str(len(current)).encode()+b'\0'+current).hexdigest() if current is not None else None
    if blob!=item['baselineGitBlob']:
        raise SystemExit('다른 채널 또는 추가 수정이 있는 파일입니다. 덮어쓰지 않았습니다: '+item['path'])
    changes.append((source,target))
print(args.channel,'baseline:',manifest['sourceCommit'],'files to apply:',len(changes))
if args.apply:
    for source,target in changes:
        target.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(source,target)
    history=repo/'수정이력.md'
    marker=(args.channel+'-heading-controls-20261122').encode()
    if marker not in (history.read_bytes() if history.exists() else b''):
        with history.open('ab')as stream:stream.write((bundle/'history-append.txt').read_bytes())
    print('Applied. Existing history preserved; no git commit, push or publish performed.')
else:
    print('검사만 완료했습니다. 적용하려면 --apply를 추가하세요.')
