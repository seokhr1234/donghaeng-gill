const assert=require('node:assert/strict');
const Heading=require(process.argv[2]);
function setup({permission='granted',supported=true}={}){
 const events=new Map(),timers=new Map(),updates=[];let serial=0,time=1000,prompts=0;
 const target={isSecureContext:true,screen:{orientation:{angle:0}},
  DeviceOrientationEvent:supported?{requestPermission:async absolute=>{assert.equal(absolute,true);prompts++;return permission}}:undefined,
  addEventListener:(name,fn)=>{if(!events.has(name))events.set(name,new Set());events.get(name).add(fn)},
  removeEventListener:(name,fn)=>events.get(name)?.delete(fn)};
 const controller=Heading.create({target,now:()=>time,timers:{setInterval:fn=>{timers.set(++serial,fn);return serial},clearInterval:id=>timers.delete(id)},onUpdate:value=>updates.push(value)});
 return {controller,target,updates,events,timers,get prompts(){return prompts},event:(value)=>{for(const fn of events.get('deviceorientation')||[])fn(value)},expire:()=>{time+=7000;for(const fn of timers.values())fn()}};
}
(async()=>{
 assert.equal(Heading.fromEvent({absolute:true,alpha:0}),0);
 assert.equal(Heading.fromEvent({absolute:true,alpha:270}),90);
 assert.equal(Heading.fromEvent({absolute:true,alpha:0},90),90);
 assert.equal(Heading.fromEvent({webkitCompassHeading:350,webkitCompassAccuracy:5},90),80);
 for(const value of [{absolute:false,alpha:10},{absolute:true,alpha:null},{webkitCompassHeading:10,webkitCompassAccuracy:-1},{webkitCompassHeading:10,webkitCompassAccuracy:60}])assert.equal(Heading.fromEvent(value),null);
 const h=setup();assert(await h.controller.start());assert.equal(h.prompts,1);
 h.event({absolute:false,alpha:20});assert.equal(h.controller.snapshot().degrees,null);
 h.event({absolute:true,alpha:1});h.event({absolute:true,alpha:359});
 assert(h.controller.snapshot().degrees>350||h.controller.snapshot().degrees<10);
 h.expire();assert.equal(h.controller.snapshot().phase,'stale');assert.equal(h.controller.snapshot().degrees,null);
 h.event({absolute:true,alpha:270});assert.equal(h.controller.snapshot().degrees,90);
 h.controller.stop();assert.equal(h.timers.size,0);assert([...h.events.values()].every(set=>set.size===0));
 await h.controller.start();assert.equal(h.prompts,1);h.controller.stop();
 const denied=setup({permission:'denied'});assert.equal(await denied.controller.start(),false);assert.equal(denied.controller.snapshot().phase,'denied');assert.equal(denied.timers.size,0);
 const unsupported=setup({supported:false});await unsupported.controller.start();assert.equal(unsupported.controller.snapshot().phase,'unsupported');
 const insecure=setup();insecure.target.isSecureContext=false;await insecure.controller.start();assert.equal(insecure.controller.snapshot().phase,'insecure');
 const native=setup();let remove=0,callback;
 native.target.DonghaengHeading={start:async fn=>{callback=fn;return()=>remove++}};
 await native.controller.start();callback({degrees:90,reliable:true});assert.equal(native.controller.snapshot().degrees,90);callback({reliable:false});assert.equal(native.controller.snapshot().phase,'calibrating');native.controller.stop();assert.equal(remove,1);
 console.log(JSON.stringify({pass:true,checks:['Cardinals, screen rotation and iOS compass accuracy','Relative/null headings rejected; circular smoothing across north','Stale sensor output hidden and recoverable','Permission denial, insecure and unsupported environments','Listeners/timers cleaned and granted permission reused','Native fused heading and unreliable readings handled']}));
})().catch(cause=>{console.error(cause);process.exitCode=1});
