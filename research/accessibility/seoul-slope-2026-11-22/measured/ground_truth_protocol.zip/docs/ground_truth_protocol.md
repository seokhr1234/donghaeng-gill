# Ground-Truth Annotation Protocol

This document describes how the ground-truth attributes in the **Seoul Sidewalk Accessibility Image Dataset** were measured and annotated.

The dataset includes three field-measured attributes and one visually assessed attribute:

- Sidewalk width
- Longitudinal slope
- Cross slope
- Pavement condition

## 1. Sidewalk Width

Sidewalk width represents the measured width of the sidewalk.

The value is recorded in meters in the `width` column of `ground_truth.csv`.

## 2. Longitudinal Slope

Longitudinal (running) slope represents the slope measured along the direction of pedestrian travel.

The value is recorded in degrees in the `running_slope` column of `ground_truth.csv`.

## 3. Cross Slope

Cross slope represents the slope measured across the sidewalk, from right to left.

The value is recorded in degrees in the `cross_slope_deg` column of `ground_truth.csv`.

## 4. Pavement Condition

Pavement condition was visually assessed using the five-grade service-level classification shown below.

The source guideline states that sidewalks should be maintained at **Grade C or higher** at minimum. Maintaining **Grade B or higher** is desirable to provide smooth and comfortable passage for pedestrians and mobility-impaired users.

### Grade A — Very Good

A sidewalk pavement condition with no plastic deformation or cracking; newly constructed or in like-new condition.

![Example of Grade A pavement condition](pavement_grade_A.jpeg)

### Grade B — Good

A pavement condition in which the sidewalk surface is not entirely smooth but maintains a uniform condition overall.

![Example of Grade B pavement condition](pavement_grade_B.jpeg)

### Grade C — Fair

A pavement condition that allows passage by pedestrians and mobility-impaired users but may require consideration of resurfacing or similar measures, depending on the degree of pavement deterioration.

![Example of Grade C pavement condition](pavement_grade_C.jpeg)

### Grade D — Poor

A pavement condition severe enough to affect normal passage by pedestrians and mobility-impaired users.

This grade includes conditions in which hazards exist on **50% or more** of the pavement.

![Example of Grade D pavement condition](pavement_grade_D.jpeg)

### Grade E — Very Poor

A condition in which normal passage is not possible.

This grade includes conditions in which hazards exist on **75% or more** of the pavement.

![Example of Grade E pavement condition](pavement_grade_E.jpeg)

## 5. Ground-Truth File Format

Each row in `ground_truth.csv` corresponds to one image.

```csv
filename,width_px,height_px,latitude,longitude,width,running_slope,cross_slope,damage
IMG_8956.JPG,5712,4284,37.5624444,126.942656,2.99,1.3,-0.9,A
IMG_8957.JPG,5712,4284,37.5624778,126.942733,2.85,0.3,1.4,A
```

## 6. Source

The pavement-condition grading criteria and example images are sourced from the Korean Ministry of Land, Infrastructure and Transport guideline **보도 설치 및 관리 지침** (*Guidelines for Sidewalk Installation and Management*).

The English descriptions presented in this repository are translations prepared for documentation purposes. Users should consult the original Korean guideline when an authoritative interpretation is required.
